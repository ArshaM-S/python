file=input("Enter the file name: ")
file_list=file.split(".")
print("File extension is: ",file_list[-1])
