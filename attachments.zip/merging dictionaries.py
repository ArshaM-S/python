mydict1={}
print("Enter elements of first dic: ")
while True:
    key=input("enter a key (or q to quit): ")
    if key=='q':
        break
    value=int(input("enter a value: "))
    mydict1[key]=value
print("Enter elements of second dic: ")
mydict2={}
while True:
    
    
