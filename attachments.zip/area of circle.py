r=int(input("Enter the radius of the circle: "))
print("Area of the circle: ",3.14*r*r,"square units")
